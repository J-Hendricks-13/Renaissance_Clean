import streamlit as st
import streamlit.components.v1 as components
from data.artworks import ARTWORKS


ROOM_SCENES = {
    "Modern Living Room": {
        "emoji": "🛋️",
        "wall_default": "#F5F1EA",
        "description": "A warm premium living-room setting for residential collectors.",
    },
    "Minimal Office": {
        "emoji": "🏢",
        "wall_default": "#EAECEF",
        "description": "A clean executive setting for offices, studios, and boardrooms.",
    },
    "Gallery Space": {
        "emoji": "🖼️",
        "wall_default": "#FFFFFF",
        "description": "A curated exhibition-style environment for serious presentation.",
    },
}


FRAME_STYLES = {
    "None": {
        "border": "0px solid transparent",
        "padding": "0px",
        "background": "transparent",
        "shadow": "none",
    },
    "Black": {
        "border": "10px solid #111111",
        "padding": "6px",
        "background": "#111111",
        "shadow": "0 8px 24px rgba(0,0,0,0.25)",
    },
    "White": {
        "border": "10px solid #F8F8F8",
        "padding": "6px",
        "background": "#F8F8F8",
        "shadow": "0 8px 24px rgba(0,0,0,0.18)",
    },
    "Oak": {
        "border": "12px solid #A67C52",
        "padding": "6px",
        "background": "#A67C52",
        "shadow": "0 8px 24px rgba(0,0,0,0.22)",
    },
    "Gold": {
        "border": "12px solid #C9A227",
        "padding": "6px",
        "background": "#C9A227",
        "shadow": "0 8px 24px rgba(0,0,0,0.22)",
    },
}


def add_to_cart(artwork: dict):
    st.session_state.cart.append(artwork)
    st.toast(f"{artwork['title']} added to cart.", icon="✅")


def get_artwork_by_title(title: str):
    for artwork in ARTWORKS:
        if artwork["title"] == title:
            return artwork
    return ARTWORKS[0]


def render_preview_stage(
    artwork: dict,
    room_name: str,
    wall_color: str,
    frame_style: str,
    artwork_width_percent: int,
    immersive_mode: bool,
):
    room = ROOM_SCENES[room_name]
    frame = FRAME_STYLES[frame_style]

    stage_height_px = 820 if immersive_mode else 560
    artwork_width = f"{artwork_width_percent}%"
    room_label = f"{room['emoji']} {room_name}"

    preview_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body {{
                margin: 0;
                padding: 0;
                background: transparent;
                font-family: Arial, sans-serif;
            }}

            .preview-shell {{
                border: 1px solid #e9e9e9;
                border-radius: 22px;
                overflow: hidden;
                background: #f8f8f8;
                box-shadow: 0 10px 30px rgba(0,0,0,0.06);
            }}

            .preview-header {{
                padding: 14px 18px;
                background: #ffffff;
                border-bottom: 1px solid #ececec;
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: 14px;
            }}

            .preview-badge {{
                background: #111;
                color: #fff;
                padding: 6px 10px;
                border-radius: 999px;
                font-size: 12px;
                white-space: nowrap;
            }}

            .preview-stage {{
                position: relative;
                height: {stage_height_px}px;
                background: linear-gradient(
                    to bottom,
                    {wall_color} 0%,
                    {wall_color} 74%,
                    #c9b8a6 74%,
                    #b79f89 100%
                );
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 28px;
                box-sizing: border-box;
            }}

            .floor-line {{
                position: absolute;
                left: 0;
                right: 0;
                bottom: 18%;
                height: 6px;
                background: rgba(255,255,255,0.35);
                filter: blur(2px);
            }}

            .artwork-wrap {{
                width: {artwork_width};
                max-width: 700px;
                min-width: 180px;
                text-align: center;
                z-index: 2;
            }}

            .frame {{
                border: {frame['border']};
                padding: {frame['padding']};
                background: {frame['background']};
                box-shadow: {frame['shadow']};
                border-radius: 4px;
                display: inline-block;
                box-sizing: border-box;
            }}

            .frame img {{
                width: 100%;
                display: block;
                border-radius: 2px;
            }}

            .artwork-label {{
                margin-top: 16px;
                display: inline-block;
                background: rgba(255,255,255,0.88);
                padding: 10px 14px;
                border-radius: 14px;
                box-shadow: 0 4px 14px rgba(0,0,0,0.08);
            }}

            .artwork-title {{
                font-weight: 700;
                font-size: 15px;
                color: #111;
            }}

            .artwork-meta {{
                color: #666;
                font-size: 13px;
                margin-top: 2px;
            }}
        </style>
    </head>
    <body>
        <div class="preview-shell">
            <div class="preview-header">
                <div>
                    <div><strong>{room_label}</strong></div>
                    <div style="color:#666; font-size:12px; margin-top:2px;">
                        {room['description']}
                    </div>
                </div>
                <div class="preview-badge">Immersive Preview</div>
            </div>

            <div class="preview-stage">
                <div class="floor-line"></div>

                <div class="artwork-wrap">
                    <div class="frame">
                        <img src="{artwork['image']}" alt="{artwork['title']}">
                    </div>

                    <div class="artwork-label">
                        <div class="artwork-title">{artwork['title']}</div>
                        <div class="artwork-meta">
                            by {artwork['artist']} • {artwork['dimensions']}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    """

    components.html(preview_html, height=stage_height_px + 90, scrolling=False)

def render_artwork_details(artwork: dict):
    st.subheader("Artwork Details")
    st.write(f"**Title:** {artwork['title']}")
    st.write(f"**Artist:** {artwork['artist']}")
    st.write(f"**Category:** {artwork['category']}")
    st.write(f"**Medium:** {artwork['medium']}")
    st.write(f"**Dimensions:** {artwork['dimensions']}")
    st.write(f"**Price:** ZAR {artwork['price']:,}")
    st.write(f"**Description:** {artwork['description']}")

    st.divider()

    if st.button("Add to Collection", type="primary", use_container_width=True):
        add_to_cart(artwork)

    if st.button("Save as Favorite", use_container_width=True):
        if artwork["id"] not in st.session_state.favorites:
            st.session_state.favorites.append(artwork["id"])
            st.toast("Saved to favorites.", icon="❤️")
        else:
            st.toast("Already in favorites.", icon="ℹ️")


def render_buyer_confidence_block(room_name: str, frame_style: str, artwork_width_percent: int):
    st.subheader("Why this helps the buyer")
    st.markdown(
        f"""
        - **Room context:** The artwork is being previewed inside a **{room_name.lower()}** setting.
        - **Presentation control:** The buyer can evaluate it with a **{frame_style.lower()} frame**.
        - **Scale confidence:** The artwork is currently shown at **{artwork_width_percent}% display width** to simulate fit and visual dominance.
        - **Decision support:** This reduces the uncertainty that usually blocks online art purchases.
        """
    )


def render_immersive_demo_page():
    st.title("🪄 Immersive Art Experience")

    st.markdown(
        """
        <div style="
            padding: 1.2rem 1.4rem;
            border: 1px solid #ececec;
            border-radius: 18px;
            background: linear-gradient(135deg, #ffffff 0%, #f8f5f1 100%);
            margin-bottom: 1rem;
        ">
            <h3 style="margin-bottom: 0.4rem;">Visualize art before you buy</h3>
            <p style="margin-bottom: 0; color: #666;">
                This immersive demo simulates how artwork could feel in a real environment, helping buyers build confidence before purchase.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    artwork_titles = [art["title"] for art in ARTWORKS]
    default_title = artwork_titles[0]

    top_left, top_mid, top_right = st.columns([2, 1, 1])

    with top_left:
        selected_title = st.selectbox("Select artwork", artwork_titles, index=0)

    with top_mid:
        selected_room = st.selectbox("Room scene", list(ROOM_SCENES.keys()), index=0)

    with top_right:
        immersive_mode = st.toggle("Immersive mode", value=False)

    selected_artwork = get_artwork_by_title(selected_title)
    default_wall = ROOM_SCENES[selected_room]["wall_default"]

    control_left, control_mid, control_right = st.columns(3)

    with control_left:
        wall_color = st.color_picker("Wall color", value=default_wall)

    with control_mid:
        frame_style = st.selectbox("Frame style", list(FRAME_STYLES.keys()), index=1)

    with control_right:
        artwork_width_percent = st.slider("Artwork scale", min_value=25, max_value=80, value=45, step=5)

    st.divider()

    preview_col, info_col = st.columns([2.2, 1], gap="large")

    with preview_col:
        render_preview_stage(
            artwork=selected_artwork,
            room_name=selected_room,
            wall_color=wall_color,
            frame_style=frame_style,
            artwork_width_percent=artwork_width_percent,
            immersive_mode=immersive_mode,
        )

    with info_col:
        render_artwork_details(selected_artwork)

    st.divider()

    lower_left, lower_right = st.columns([1.2, 1])

    with lower_left:
        render_buyer_confidence_block(
            room_name=selected_room,
            frame_style=frame_style,
            artwork_width_percent=artwork_width_percent,
        )

    with lower_right:
        st.subheader("Demo value")
        st.markdown(
            """
            - Builds purchase confidence
            - Makes the platform feel premium
            - Shows a clear direction toward AR/VR
            - Gives clients a visual reason to believe in the concept
            """
        )