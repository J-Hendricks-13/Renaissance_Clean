import streamlit as st
import streamlit.components.v1 as components


FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSetYCnSPJTqHROd-EdKqLaKFrKOegghxYBmnmvGuuHEBjpeYg/viewform?embedded=true"


def render_artist_onboarding_page():
    st.title("🎨 For Artists & Galleries")

    # --- Section 1: Positioning ---
    st.markdown(
        """
        <div style="
            padding: 1.2rem 1.4rem;
            border: 1px solid #ececec;
            border-radius: 18px;
            background: linear-gradient(135deg, #ffffff 0%, #f8f5f1 100%);
            margin-bottom: 1rem;
        ">
            <h3 style="margin-bottom: 0.4rem;">Show your work in a new way</h3>
            <p style="margin-bottom: 0; color: #666;">
                Renaissance is building a premium digital experience for discovering and purchasing art.
                We help collectors visualize artwork in real environments before they buy.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # --- Section 2: Value ---
    col1, col2 = st.columns(2)

    with col1:
        st.subheader("Why join")
        st.markdown(
            """
            - Reach serious collectors
            - Showcase your work in immersive environments
            - Be part of curated digital exhibitions
            - Early access to platform growth
            """
        )

    with col2:
        st.subheader("What we’re looking for")
        st.markdown(
            """
            - Original artwork (digital, painting, sculpture, mixed media)
            - Strong visual identity
            - Artists and galleries open to online sales
            - Consistent body of work
            """
        )

    st.divider()

    # --- Section 3: CTA ---
    st.subheader("Apply to be featured")

    st.markdown(
        """
        <p style="color:#666;">
        Fill in the form below to submit your work. Selected artists will be contacted
        for onboarding and feature placement.
        </p>
        """,
        unsafe_allow_html=True,
    )

    # --- Section 4: Embedded Form ---
    components.html(
        f"""
        <iframe src="{FORM_URL}" width="100%" height="900" frameborder="0">
        Loading…
        </iframe>
        """,
        height=920,
        scrolling=True,
    )